// ==========================================================================
// Gulp Babel : 
// ==========================================================================


import { src, dest, series } from 'gulp';
import imagemin from "gulp-imagemin";
import browserSync from "browser-sync";
import notify from "gulp-notify";
import log from "fancy-log";

import { pkgMedia } from './theme.vars';

// copy media to output directory

const themeMedia = async () => {
    // function themeMedia() {
    //console.log(importScss);
    return src(pkgMedia.filepath + pkgMedia.ext, { allowEmpty: true })
        //.pipe(imagemin({ optimizationLevel: 3, progressive: true, interlaced: true }))
        .pipe(imagemin([
            imagemin.gifsicle({ interlaced: true }),
            imagemin.mozjpeg({ progressive: true }),
            imagemin.optipng({ optimizationLevel: 5 }),
            imagemin.svgo({ 
                plugins: [
                    { removeViewBox: true },
                    { cleanupIDs: false }
                ]
            })
        ], {
            verbose: true
        }))
        .on("error", log)
        .pipe(browserSync.reload({ stream: true }))
        .pipe(dest(pkgMedia.dest));
        // .pipe(notify({ message: 'Images task complete', onLast: true }));
};

module.exports = series(themeMedia);
